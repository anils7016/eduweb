app.controller("MainController", [
    "$scope",
    "DataService",
    "$http","$route", "$rootScope","pageTitle",
    function ($scope, DataService, $http, $route, $rootScope, pageTitle ) {
    // Controller logic here
    $scope.dynamicTitle = 'United States Bir Tikendrajit University';
    $scope.title = pageTitle;
    $rootScope.dynamicTitle = $scope.title;


    // Listen for route changes
    // $rootScope.$on('$routeChangeSuccess', function(event, current, previous) {
    //     // Update title based on the current route
    //     if (current.$$route && current.$$route.title) {
    //         $scope.dynamicTitle = current.$$route.title;
    //     } else {
    //         $scope.dynamicTitle = 'United States Bir Tikendrajit University';
    //     }
    // });

    $scope.message = "Hello from MainController!";
    $scope.isHomePage = true;

    $http.get("admin/api/countries").then(
      function (response) {
        $scope.countries = response?.data?.data;
        //console.log("$scope.countries", $scope.countries);
      },
      function (error) {
        console.error("Error fetching countries:", error);
      }
    );
    $scope.saveRequest = function (formId) {
      console.log("id", formId);

      console.log("formData", $scope.formData);
      //if ( angular.element("#" + formId).valid() ) {
      console.log("formData==save", $scope.formData);
      $scope.successMessage = '';
      $http.post("admin/api/general", $scope.formData).then(
        function (response) {
          console.log('response', response)

          if(response?.data?.data){
            $scope.successMessage = 'Data saved successfully!';

            setTimeout(() => {
              $scope.successMessage = '';
              $route.reload();
            }, 2000);

          }

          
        },
        function (error) {
          console.error("Error fetching countries:", error);
        }
      );

      //}
    };

    $http.get("admin/api/general").then(
      function (response) {
        console.log('response', response)
        $scope.courses = response?.data?.data;
        console.log('$scope.course', $scope.course)
        $scope.courseAcademic = $scope.courses.filter( (item) => item.category_id == 1 );
        $scope.courseBechelor = $scope.courses.filter( (item) => item.category_id == 2 );
        $scope.courseMaster = $scope.courses.filter( (item) => item.category_id == 3 );
        console.log('$scope.courseAcademic', $scope.courseAcademic)
        
      },
      function (error) {
        console.error("Error fetching countries:", error);
      }
    );

  },
]);
